This is AvalonEdit 4.2.0.8783.

Code Project article: http://www.codeproject.com/KB/edit/AvalonEdit.aspx
AvalonEdit website:   http://www.avalonedit.net/
SharpDevelop website: http://www.icsharpcode.net/OpenSource/SD/

Copyright Daniel Grunwald, 2008-2012
ICSharpCode.AvalonEdit is licensed under the GNU LGPL. See license.txt for details.
The AvalonEdit.Sample application is licensed under the MIT/X11 license. See the file headers of AvalonEdit.Sample\*.cs for details.
